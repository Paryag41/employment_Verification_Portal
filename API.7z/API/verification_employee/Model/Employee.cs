﻿namespace verification_employee.Model
{
    public class Employee
    {
       public string EmployeeId { get; set; }
        public string CompanyName { get; set; }
        public string VerificationCode { get; set; }

    }
}
