﻿namespace verification_employee.Model
{
    public class VerifyEmploymentResponse
    {
       public bool IsVerified { get; set; }
        public string Message { get; set; }
    }
}

