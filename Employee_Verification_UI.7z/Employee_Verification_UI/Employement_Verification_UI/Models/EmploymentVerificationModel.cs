﻿namespace Employement_Verification_UI.Models
{
    public class EmploymentVerificationModel
    {
        public string EmployeeId { get; set; }
        public string CompanyName { get; set; }
        public string VerificationCode { get; set; }

    }
}
